
export default function App() {
  return (
    <div className="flex items-center justify-center min-h-screen text-white text-3xl">
      DreamWay Admin Працює ✅
    </div>
  );
}
